package Biblioteca;

public class Livros extends Biblioteca{
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String pais;
    private int anopublicacao;

    public Livros() {
    }

    public Livros(String titulo, String autor, String edicao, String editora, String pais, int anopublicacao, int id) {
        super(id);
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.pais = pais;
        this.anopublicacao = anopublicacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdicao() {
        return edicao;
    }

    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String cidade) {
        this.pais = cidade;
    }

    public int getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    
    @Override
    public int getId() {
        return super.id;
    }
    
    @Override
    public String toString() {
        return "Titulo: " + titulo + "\nAutor: " + autor + "\nEdicao: " + edicao + "\nEditora: " + editora + "\nCidade: " + pais + "\nAno de Publicacao: " + anopublicacao + "\nCod.: " + super.id;
    }
    
    
    
    
    
}
